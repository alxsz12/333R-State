#include "main.h"

void Intake::RollerColor()
{
  //  if(Auton::cEnable()) //should check if its true 
    //    {
     //       Intake::Blue(); // switches to blue
      //  }
    //else if(!Auton::cEnable()) // should check if its false
      //  {
        //    Intake::Red(); // switches to red
        //}
}

void Intake::Red()
{
    int c = def::o_rollerL.get_hue();
        while (0.1 <= c <= 40.1) 
        {// while its not in the range of the color
            def::mtr_it.moveVoltage(12000);
            Drivetrain::moveArcade(-0.1, 0.0, false);
        }
            def::mtr_it.moveVoltage(0);
        
        Drivetrain::moveArcade(0.0, 0.0, false);       
        def::mtr_it.moveVoltage(0);  //then it stops the motor
        def::controller.rumble("-"); // and rumbles the controller
        pros::delay(20); // to signify that it completed the loop
}

void Intake::Blue()
{       
        IntakeStateMachine::setState(INTAKE_STATES::in); 
        while (200 <= (def::o_rollerL.get_hue()) <= 250)
        {// while its not in the rang of the color
            pros::delay(100);
        } 
        IntakeStateMachine::setState(INTAKE_STATES::off); 
        //Drivetrain::moveArcade(0.0, 0.0, false);
        //mmtr.moveVoltage(0); //then it stops the motor
        //def::controller.rumble("-");// and rumbles the controller
        //pros::delay(20); //to signify that it completed the loop
}