#include "main.h"


// ------------------------Auton.cpp-----------------------------------------//
// This file is being used to control the different robot movements during   //
// the autonomous period. We have different enumerations depending on which  //
// color side and auton is selected. This allows us to be able to use our    //
// autons more effciently so we don't have to make a bunch of different      //
// autonomous programs depending on for example the color that we were given //
// We also use this file where we upload the current selected auton from the //
// brain to be able to always have it available. Then we have the different  //
// movements that we have written down below.                                //
/*---------------------------------------------------------------------------*/

Auton::Autons Auton::auton;    // default auton is deploy, if the sd card is not installed
Auton::Sides Auton::side;      // default side is Right if the sd card is not installed
Auton::Colors Auton::color;    // default color is Red if the sd card is not installed
Auton::Colors Auton::opponent; // default color is Red if the sd card is not installed

void Auton::readSettings() // read the sd card to set the settings
{
    FILE *file;                    // cpp a file object to be used later
    if (pros::usd::is_installed()) // checks if the sd card is installed before trying to read it
    {
        file = fopen("/usd/auton_settings.txt", "r"); // open the auton settings
        if (file)                                     // check to see if the file opened correctly
        {
            int autonSideAndColor; 
            fscanf(file, "%i", &autonSideAndColor);

            auton = (Auton::Autons)(autonSideAndColor / 100);
            side = (Auton::Sides)((autonSideAndColor / 10) % 10);
            color = (Auton::Colors)(autonSideAndColor % 10);
            opponent = color == Auton::Colors::Red ? Auton::Colors::Blue : Auton::Colors::Red;

            std::cout << "autonSideAndColor in sd card is " //prints to the terminal
            << std::to_string(autonSideAndColor) << ". Auton is " // the side
            << (int)auton << ", side is " << (int)side << ", and color is " << (int)color << "." << std::endl; // color
            // and the auton selected
        }
        else
        {
            std::cout << "/usd/auton_settings.txt is null."
                      << std::endl; // if the file didn't open right, tell the terminal
        }
        fclose(file); // close the file
    }
}
void Auton::suspendAsyncTask()
{
    masync_task.suspend();
}


void Auton::cEnable()
{
    switch(color)//sequence loop to run the selected color
    {
        case Colors::Red:
            Intake::Red();
        break; 
        case Colors::Blue:
            Intake::Blue();
        break;
    }
}

void Auton::runAuton(){ // Function that controls all of the autonomous movements
    Auton::readSettings(); //Loads the autons from the SD card
    Auton::suspendAsyncTask(); //Stops the async tasks

    mstartTime = mtimer.millis(); // Timer for the auton
    waitForImu(); // Wait for calibration
    //Setting the initial state and then disabiling the controls
    DrivetrainStateMachine::disableControl();
    FlywheelStateMachine::disableControl();
    IntakeStateMachine::disableControl();
    EndGameStateMachine::disableControl();
    //Sets the states to disable controller inputs
    DrivetrainStateMachine::setState(DT_STATES::busy);

    switch (auton){ //Sequence loop to contain the different autons

        case Autons::none:
            //Doing Nothing
        break;
        
        case Autons::Test:
        //Used to test auton movements
        Drivetrain::bDist(95);//driving back to the roller
        //Intake::RollerColor();//roller
        Auton::cEnable();
        break;

        case Autons::SAWP:
        switch(side)
            {
                case Sides::Left:
                    //Drivetrain::turnToAngle(-5_deg); // turning back to be straight for the roller
                    Flywheel::AShoot115(true); //Shooting at the high goal
                    //Drivetrain::turnToAngle(0_deg);
                    pros::delay(1000);
                    Drivetrain::bDist(95);//driving back to the roller
                    Intake::RollerColor();//roller
                    Drivetrain::straightForDistance(2.5_in);//drives forward
                    Drivetrain::turnToAngle(49_deg); //turns to face the center of the field
                    //Drivetrain::straightForDistance(24_in);//Drives to the center of the field
                    IntakeStateMachine::setState(INTAKE_STATES::out);//allows to intake discs
                    Drivetrain::straightForDistance(14_in); //drives to intake the dics
                    Drivetrain::straightForDistance(12_in);
                    pros::delay(1000);
                    IntakeStateMachine::setState(INTAKE_STATES::off); //turns the intake off
                    Drivetrain::turnToAngle(-25_deg); //turns to face the high goal
                    Flywheel::AShoot10(false);
                    Drivetrain::turnToAngle(49_deg); //turns to face the center of the field
                    IntakeStateMachine::setState(INTAKE_STATES::out);
                    Drivetrain::straightForDistance(24_in);
                    Drivetrain::turnToAngle(-25_deg); // turns back to face the high goal 
                    Flywheel::AShoot115(false);
                break;

                case Sides::Right:
                    IntakeStateMachine::setState(INTAKE_STATES::out); // Starts the intake 
                    FlywheelStateMachine::setState(FW_STATES::Eleven); //Starts the flywheel
                    pros::delay(250); // waits for the intake to start
                    Drivetrain::straightForDistance(16_in); //drives forward to the first disc
                    pros::delay(900); // waits for the disc to intake
                    IntakeStateMachine::setState(INTAKE_STATES::off);//turns the intake off
                    Drivetrain::turnToAngle(30.5_deg); //turns to the high goal
                    Flywheel::AShoot115(true); //shoots the discs
                    pros::delay(900); // waits for the fly to stop shooting 
                    Drivetrain::turnToAngle(-40_deg); //turns to the roller
                    Drivetrain::straightForDistance(-24_in); //drives to the roller
                    Drivetrain::turnToAngle(1_deg);//Turns into the roller
                    Drivetrain::bDist(95);//driving back to the roller
                    Intake::RollerColor();//roller
                    Drivetrain::straightForDistance(2.5_in);//drives forward
                break;
            }

        break;
        }
}

void Auton::startAsyncTaskWithSettings(std::function<bool()> iasyncCondition, std::function<void()> iasyncAction)
{
    masyncCondition = iasyncCondition;
    masyncAction = iasyncAction;
    masync_task.resume();
}
void Auton::async_task_func(void *)
{
    while (true)
    {
        if (masyncCondition())
        {
            masyncAction();
            masync_task.suspend();
        }
        pros::delay(20);
    }
}
std::function<bool()> Auton::masyncCondition = []()
{ return false; };
std::function<void()> Auton::masyncAction;
pros::Task Auton::masync_task(Auton::async_task_func);

void Auton::startTaskAfterDelay(QTime idelay, std::function<void()> iaction)
{
    mdelayAction = iaction;
    mdelayTime = idelay;
    mdelay_task.resume();
}
void Auton::delay_task_func(void *)
{
    while (true)
    {
        if (mtimer.millis() - mstartTime > mdelayTime)
        {
            mdelayAction();
            mdelay_task.suspend();
        }
        pros::delay(20);
    }
}
std::function<void()> Auton::mdelayAction;
Timer Auton::mtimer = Timer();
QTime Auton::mstartTime = 0_ms;
QTime Auton::mdelayTime = 2_min;
pros::Task Auton::mdelay_task(Auton::delay_task_func);