#pragma once
#include "main.h"

class Flywheel
{
public:
static void AShoot12(bool wait);
static void AShoot115(bool wait);
static void AShoot11(bool wait);
static void AShoot10(bool wait);
};

namespace def
{
extern Flywheel flywheel;  
}

static int volt;